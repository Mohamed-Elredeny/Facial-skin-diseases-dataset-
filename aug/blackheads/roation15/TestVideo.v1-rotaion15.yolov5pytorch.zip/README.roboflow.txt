
TestVideo - v1 Rotaion15
==============================

This dataset was exported via roboflow.ai on January 27, 2021 at 2:38 PM GMT

It includes 264 images.
TestVideo are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -15 and +15 degrees


